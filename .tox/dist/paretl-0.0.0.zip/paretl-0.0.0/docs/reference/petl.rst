paretl
====

.. testsetup::

    from paretl import *

.. automodule:: paretl
    :members:
