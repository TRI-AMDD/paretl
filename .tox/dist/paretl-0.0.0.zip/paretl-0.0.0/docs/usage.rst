=====
Usage
=====

To use paretl in a project::

	import paretl
