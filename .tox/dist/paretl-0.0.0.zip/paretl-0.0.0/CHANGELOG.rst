
Changelog
=========

0.0.0 (2020-12-03)
------------------

* First release on PyPI.
